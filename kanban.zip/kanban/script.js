let draggedTask = null;
// перетаскивание
function drag(ev) {
    if (ev.target.querySelector('.task-input')) {
        ev.preventDefault();
        return;
    }
    draggedTask = ev.target;
    ev.dataTransfer.setData("text/plain", ev.target.innerText);
    ev.target.classList.add('dragging');
}
// разрешение на сброс бомбы
function allowDrop(ev) {
    ev.preventDefault();
    ev.currentTarget.classList.add('drag-over');
}

function dragLeave(ev) {
    ev.currentTarget.classList.remove('drag-over');
}
// тачдаун
function drop(ev) {
    ev.preventDefault();
    document.querySelectorAll('.column').forEach(col => col.classList.remove('drag-over'));
    const targetColumn = ev.currentTarget;
    const targetTasksContainer = targetColumn.querySelector('.tasks');
    if (draggedTask && document.body.contains(draggedTask)) {
        draggedTask.classList.remove('dragging');
        targetTasksContainer.appendChild(draggedTask);
        draggedTask = null;
    }
}
// удаление
function deleteTask(btn, event) {
    event.stopPropagation();
    const task = btn.closest('.task');
    if (draggedTask === task) draggedTask = null;
    task.remove();
}
// созидание
function createEmptyTask(btn) {
    const column = btn.closest('.column');
    const tasksContainer = column.querySelector('.tasks');
    const newTask = document.createElement('div');
    newTask.className = 'task';
    newTask.draggable = true;

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'task-input';

    const deleteBtn = document.createElement('div');
    deleteBtn.className = 'delete-btn';
    deleteBtn.innerHTML = '✕';
    deleteBtn.onclick = function(e) { deleteTask(this, e); };

    newTask.appendChild(input);
    newTask.appendChild(deleteBtn);
    newTask.addEventListener('dragstart', drag);
    tasksContainer.appendChild(newTask);

    input.focus();
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            finishInput(input);
        }
    });
    input.addEventListener('blur', function() {
        finishInput(input);
    });
}

function finishInput(input) {
    const task = input.closest('.task');
    const text = input.value.trim();
    if (text === '') {
        task.remove();
    } else {
        const textNode = document.createTextNode(text);
        task.replaceChild(textNode, input);
        task.appendChild(task.querySelector('.delete-btn'));
    }
}

document.querySelectorAll('.column').forEach(col => {
    col.addEventListener('dragover', allowDrop);
    col.addEventListener('dragleave', dragLeave);
    col.addEventListener('drop', drop);
});