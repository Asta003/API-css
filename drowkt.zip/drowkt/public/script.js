const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const ws = new WebSocket(`ws://${location.host}`);
const colorPicker = document.getElementById('colorPicker');
const sizePicker = document.getElementById('sizePicker');
const eraserBtn = document.getElementById('eraserBtn');
const clearBtn = document.getElementById('clearBtn');

let isDrawing = false;
let isEraser = false;
let lastX = 0;
let lastY = 0;

// подгонка размера холста
function resizeCanvas() {
    // сохраняем текужее изображ чтобы не стерлось
    let tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    tempCanvas.getContext('2d').drawImage(canvas, 0, 0);
    // меняем размер
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight - document.querySelector('.toolbar').offsetHeight;
    // возвращаем изображение на уже новый холст
    ctx.drawImage(tempCanvas, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// ластик
eraserBtn.addEventListener('click', () => {
    isEraser = !isEraser;
    eraserBtn.classList.toggle('active', isEraser);
});
// очистка холста
clearBtn.addEventListener('click', () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ws.send(JSON.stringify({ type: 'clear' }));
});

// координаты 
function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
}

canvas.addEventListener('mousedown', (e) => {
    isDrawing = true;
    const pos = getMousePos(e);
    [lastX, lastY] = [pos.x, pos.y];
});

canvas.addEventListener('mousemove', (e) => {
    if (!isDrawing) return;
    const pos = getMousePos(e);
    drawLine(lastX, lastY, pos.x, pos.y, true);
    [lastX, lastY] = [pos.x, pos.y];
});

canvas.addEventListener('mouseup', () => isDrawing = false);
canvas.addEventListener('mouseout', () => isDrawing = false);

// рисуем и спрашиваем отправление
function drawLine(x1, y1, x2, y2, sendToServer) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    
    ctx.strokeStyle = isEraser ? '#FFFFFF' : colorPicker.value;
    ctx.lineWidth = sizePicker.value;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // рисуем и закрываем
    ctx.stroke();
    ctx.closePath();

    // если отправляем то передаем данные
    if (sendToServer) {
        ws.send(JSON.stringify({
            type: 'draw',
            x1: x1, y1: y1,
            x2: x2, y2: y2,
            color: colorPicker.value,
            size: sizePicker.value,
            isEraser: isEraser
        }));
    }
}

// помучение даннах от др пользователей
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'draw') {
        ctx.beginPath();
        ctx.moveTo(data.x1, data.y1);
        ctx.lineTo(data.x2, data.y2);
        
        ctx.strokeStyle = data.isEraser ? '#FFFFFF' : data.color;
        ctx.lineWidth = data.size;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        ctx.stroke();
        ctx.closePath();
    } 
    // локал очистка
    else if (data.type === 'clear') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
};