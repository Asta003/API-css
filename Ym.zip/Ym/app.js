let locationBlock = document.getElementById("location");
let map;
let ymapsLib;
let currentMarkers = [];   
let currentPoints = [];    

const STORAGE_KEY = "map_point_sets";
const LAST_KEY = "last_loaded_set";
// Это для локации
const getLocation = () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            positionCallback,
            errorPostionCallBack
        );
    } else {
        locationBlock.innerHTML = "Браузер или устройство не поддерживает геолокацию";
    }
};
// это если разрешили доступ к ней
const positionCallback = (position) => {
    console.log(position)
    locationBlock.innerHTML = `Ваши координаты: ${position.coords.longitude}-${position.coords.latitude}`
    map.setLocation({
        center:[position.coords.longitude, position.coords.latitude],
        zoom: 50
    })
}
// Это если нет
const errorPostionCallBack = () => {
    console.log("test");
    locationBlock.innerHTML = "Вы не поделились локацией, сорри без неё не работаю";
};

getLocation()

initMap();
// для якарты
async function initMap() {
    await ymaps3.ready;
// достаём что надо
    const { YMap, YMapDefaultSchemeLayer, YMapListener, YMapDefaultFeaturesLayer } = ymaps3;
    ymapsLib = ymaps3;

    map = new YMap(document.getElementById("map"), {
        location: {
            center: [37.588144, 55.733842],
            zoom: 10
        }
    });
// схема карты
    map.addChild(new YMapDefaultSchemeLayer());
    // доп объекты
    map.addChild(new YMapDefaultFeaturesLayer());
// клик по карте 
    const clickCallback = (object, event) => {
        console.log("CLICK:", object, event);
        if (event && event.coordinates) {
            addMarkerToMap(event.coordinates, false);
        }
    };

    const mapListener = new YMapListener({
        layer: "any",
        onClick: clickCallback
    });
    map.addChild(mapListener);

    initUI();

// восстановление после перезагрузки страницы
    const sets = getSets();
    const lastLoaded = localStorage.getItem(LAST_KEY);
// грузим сборник или черновик
    if (lastLoaded && sets[lastLoaded]) {
        loadSet(lastLoaded, false);
    } else if (sets["__current__"] && sets["__current__"].length) {
        sets["__current__"].forEach(p => addMarkerToMap(p, true));
    }

    getLocation();
}
// добавляем маркер на карту
const addMarkerToMap = (point, skipSave = false) => {
    const { YMapMarker } = ymapsLib;

    const markerElement = document.createElement("img");
    markerElement.src = "./marker.png";
    markerElement.style = "width:40px; transform: translate(-20px,-40px)";
    markerElement.className = "marker-class";

    console.log("Adding marker:", point);

    const marker = new YMapMarker(
        {
            coordinates: [point[0], point[1]],
            mapFollowingOnDrag: false
        },
        markerElement
    );
    map.addChild(marker);

    currentMarkers.push(marker);
    currentPoints.push([point[0], point[1]]);
};
// отчистка и удаление маркеров
const clearMapMarkers = () => {
    currentMarkers.forEach(m => {
        try { map.removeChild(m); } catch (e) {}
    });
    currentMarkers = [];
    currentPoints = [];
};
// это для сторедж , если нет то возвращает объект
function getSets() {
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
    } catch (e) {
        return {};
    }
}
// записывает сборники в сторедж
function saveSets(sets) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sets));
}
// созраняет точки 
function saveCurrentPoints() {
    const sets = getSets();
    sets["__current__"] = currentPoints;
    saveSets(sets);
}
// привязка к обработчикам
function initUI() {
    // по всем строкам продится
    document.querySelectorAll(".set-row").forEach(row => {
        const setName = row.dataset.set;
        // загрузить и удалить соответсвенно
        row.querySelector(".load-btn").addEventListener("click", () => loadSet(setName));
        row.querySelector(".delete-btn").addEventListener("click", () => deleteSet(setName));
    });
// сохранение теущего набора
    document.getElementById("save-current").addEventListener("click", () => {
        if (currentPoints.length === 0) {
            return;
        }
// для  того чтобы знать в какой набор сохраняется
        const setName = prompt("В какой набор сохранить? Введите номер (1-5):", "1");
        if (!setName) return;
// копир координатов, ибо курент пойнт изменяется а нам не нужно чтобы ссылались на 1 массив
        const sets = getSets();
        sets[setName] = currentPoints.map(p => [p[0], p[1]]);
        saveSets(sets);
        localStorage.setItem(LAST_KEY, setName);
    });
// отчистка карты полностью
    const clearBtn = document.getElementById("clear-current");
    if (clearBtn) {
        clearBtn.addEventListener("click", () => {
            clearMapMarkers();
            saveCurrentPoints();
            localStorage.removeItem(LAST_KEY);
        });
    }
}
// загрузка набора на карту
function loadSet(setName, showAlert = true) {
    const sets = getSets();
    const points = sets[setName];
// сначала отчиска
    clearMapMarkers();
// если набора нет
    if (!points || points.length === 0) {
        saveCurrentPoints();
        return;
    }
// выводит точки набора и отмечает актывным
    points.forEach(p => addMarkerToMap(p, true));
    localStorage.setItem(LAST_KEY, setName);
    saveCurrentPoints();
}
// удаляем набор
function deleteSet(setName) {
    const sets = getSets();
    delete sets[setName];
    saveSets(sets);
// и отчистка карты приудалении
    if (localStorage.getItem(LAST_KEY) === setName) {
        clearMapMarkers();
        localStorage.removeItem(LAST_KEY);
        saveCurrentPoints();
    }
}