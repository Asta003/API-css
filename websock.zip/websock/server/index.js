const WebSocket = require("ws")
const http = require("http")
const sseClients = []

const httpServer = http.createServer((req, res) => {
    if (req.url === "/events") {
        res.writeHead(200, {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*"
        })

        sseClients.push(res)
        console.log("SSE клиент подключился. Всего:", sseClients.length)

        req.on("close", () => {
            const i = sseClients.indexOf(res)
            if (i !== -1) sseClients.splice(i, 1)
            console.log("SSE клиент отключился. Всего:", sseClients.length)
        })
        return
    }
    res.writeHead(404)
    res.end()
})
// рассылка уведом
function sseBroadcast(event, data) {
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`
    sseClients.forEach(res => res.write(payload))
}

httpServer.listen(9001, () => console.log("SSE сервер на http://localhost:9001/events"))

const wsServer = new WebSocket.Server({ port: 9000 })
console.log("WS server started")

let clients = []
let counter = 0

wsServer.on("connection", onConnect)
// когда подклич
function onConnect(wsClient) {
    counter++
    const userId = counter
    console.log("Новый пользователь подключился, id =", userId)
    clients.push(wsClient)

    sseBroadcast("user-connected", { userId, message: `Пользователь ${userId} подключился к чату` })
// сооб
    wsClient.on("message", (message) => {
        try {
            const jsonMessage = JSON.parse(message)
            console.log(jsonMessage)

            clients
                .filter(c => c !== wsClient)
                .forEach(c => c.send(JSON.stringify(jsonMessage)))

            sseBroadcast("new-message", {
                userId: jsonMessage.userId,
                message: `Новое сообщение от пользователя ${jsonMessage.userId}: ${jsonMessage.message}`
            })
        } catch (error) {
            console.error(error)
        }
    })

    wsClient.on("close", () => {
        clients = clients.filter(c => c !== wsClient)
        console.log("Пользователь отключился")
        sseBroadcast("user-disconnected", { userId, message: `Пользователь ${userId} отключился` })
    })
}