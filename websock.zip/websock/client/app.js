const chatArea = document.getElementById("chat-area")
const textInput = document.getElementById("text-input")
const sendBtn = document.getElementById("send-btn")
const notifyArea = document.getElementById("notify-area")
const WS = new WebSocket("ws://localhost:9000")
const userId = Math.floor(Math.random() * 1000)
const messages = []

WS.onopen = () => console.log("Подключились к серверу")

sendBtn.onclick = () => {
    const message = textInput.value.trim()
    if (message.length < 1) {
        alert("Сообщение не может быть пустым")
        return
    }
    const jsonMessage = { userId, message }
    WS.send(JSON.stringify(jsonMessage))
    messages.push(jsonMessage)
    textInput.value = ""
    renderChat()
}
// от др чучу
WS.onmessage = (event) => {
    const jsonData = JSON.parse(event.data)
    messages.push(jsonData)
    renderChat()
}

function renderChat() {
    chatArea.innerHTML = ""
    messages.forEach(m => {
        chatArea.innerHTML += `<span><b>Пользователь ${m.userId}</b>: ${m.message}</span><br>`
    })
    chatArea.scrollTop = chatArea.scrollHeight
}

const events = new EventSource("http://localhost:9001/events")

events.addEventListener("user-connected", (e) => {
    const data = JSON.parse(e.data)
    addNotice(data.message, "#0a7")
})

events.addEventListener("user-disconnected", (e) => {
    const data = JSON.parse(e.data)
    addNotice(data.message, "#a00")
})

events.addEventListener("new-message", (e) => {
    const data = JSON.parse(e.data)
    addNotice(data.message, "#06c")
})

events.onerror = () => {
    addNotice("SSE: потеря связи с сервером уведомлений", "#a00")
}
// добавка уведом
function addNotice(text, color) {
    notifyArea.innerHTML += `<div style="color:${color}">${text}</div>`
    notifyArea.scrollTop = notifyArea.scrollHeight
}